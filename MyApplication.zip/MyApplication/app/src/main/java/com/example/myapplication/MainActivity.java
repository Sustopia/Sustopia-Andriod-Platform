package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.fenjuly.library.ArrowDownloadButton;
import com.unstoppable.submitbuttonview.SubmitButton;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    public EditText mEdtSid, mEdtPsw;
    public SubmitButton mBtnNext;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //按照界面的的顺序对应到相应的对象
        mEdtSid = (EditText) findViewById(R.id.EdtSid);
        mEdtPsw = (EditText) findViewById(R.id.EdtPsw);
        mBtnNext = (SubmitButton) findViewById(R.id.BtnNext);
        //连接监听器
        mBtnNext.setOnClickListener(BtnNextOnClick);
    }

    protected void printText() {
        int iSid = Integer.parseInt(mEdtSid.getText().toString());   //用户有输入
        String strPsw = mEdtPsw.getText().toString();
//        for(int i=0;i<100;++i)
//        {
//            try
//            {
//                Thread.sleep(10);
//            }
//            catch (InterruptedException o)
//            {
//                o.printStackTrace();
//            }
//        }

        //验证学号和密码
        if(iSid==11812202&&strPsw.equals("0425")){   //登录成功
            mBtnNext.doResult(true);
            Intent it = new Intent();
            it.setClass(MainActivity.this,SecondActivity.class);
            startActivity(it);

        }
        else{
            // 仅用作测试
            try {
                mBtnNext.doResult(false);
                new Thread(
                        new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                Handler mainHandler=new Handler(Looper.getMainLooper());
                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        Intent it = new Intent();
                                        it.setClass(MainActivity.this, SecondActivity.class);
                                        startActivity(it);
                                        //mBtnNext.reset();
                                    }
                                });
                                try {
                                    Thread.sleep(500);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                mainHandler=new Handler(Looper.getMainLooper());
                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        mBtnNext.reset();
                                    }
                                });
                            }
                        }
                ).start();


                //登录失败,弹出对话框

            }catch(Exception e){
                e.printStackTrace();
            }

        }
    }
    //设置监听器,获取学号和密码
    private View.OnClickListener BtnNextOnClick = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            //如果输入为空，直接return
            if (mEdtSid.getText().toString().equals("") || mEdtPsw.getText().toString().equals("")) {
                return;
            }
            mBtnNext.startAnimating();
            new Thread(
                    new Runnable() {
                        @Override
                        public void run() {
                                try {
                                    Thread.sleep(3000);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            Handler mainHandler=new Handler(Looper.getMainLooper());
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    printText();
                                }
                            });
                        }
                    }
            ).start();
            //mBtnNext.doResult(false);

        }
    };
}
